from django.contrib import admin 

from .models import Route 
admin.site.register(Route) 